blogs = {
    blogs: [
        {
            title: "how to get started with python",
            content: "this is python",
            slug:"python"
        },
        {
            title: "how to get started with js",
            content: "this is js",
            slug:"js"
        },
        {
            title: "how to get started with Django",
            content: "this is django",
            slug:"django"
        },
        {
            title: "how to get started with CSS",
            content: "this is css",
            slug:"css"        
        }
    ]
}

module.exports = blogs